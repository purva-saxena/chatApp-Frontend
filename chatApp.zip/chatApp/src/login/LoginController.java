/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import HTTPCall.HTTPCallAPI;
import HTTPCall.Login;
import HTTPCall.RetrofitService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import Util.Utilities;

/**
 * FXML Controller class
 *
 * @author hinas
 */
public class LoginController implements Initializable {

    @FXML
    private TextField email;

    @FXML
    private TextField password;

    @FXML
    private TextField message;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    private Utilities util = new Utilities();

    @FXML
    private void goToRegisterPage(Event event) throws IOException {

        Parent root;
        root = FXMLLoader.load(getClass().getResource("../register/Register.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Register");
        stage.show();
        //hide current page
        ((Node) (event.getSource())).getScene().getWindow().hide();
    }

    @FXML
    private void onLoginButtonClick(Event event) {

        String email = this.email.getText();
        String pass = this.password.getText();

        if (email == null || email.isEmpty() || pass == null || pass.isEmpty()) {
            this.message.setText("Enter both email and password.");
        } else if (!util.validateEmail(email)) {
            this.message.setText("Invalid email .");
        } else {
                
            RetrofitService retrofitService = new RetrofitService();
            HTTPCallAPI service = retrofitService.getService();

            Login login = new Login(email, pass);
            final Call<Login> call = service.login(login);
            
            
            // making Asynchronous call 
                call.enqueue(new Callback<Login>() {
                    @Override
                    public void onResponse(Call<Login> call, Response<Login> response) {
                        if (response.isSuccessful()) {
                            Login apiResponse = response.body();
                            
                            //API response
                            if (apiResponse.response.equals("Error")) {
                                message.setText(apiResponse.message);
                            } else {
//                        here we will do some specific work.

                            }
                        } else {
                            message.setText("Request Error :: " + response.errorBody());
                        }
                    }

                    @Override
                    public void onFailure(Call<Login> call, Throwable t) {
                        message.setText("Network Error :: " + t.getLocalizedMessage());
                        System.out.println("Network Error :: " + t.getLocalizedMessage());
                    }
                });

                
            

        }
    }

    @FXML
    public void goToForgetPass(Event event) throws IOException{
        
        Parent root;
        root = FXMLLoader.load(getClass().getResource("../ForgotPass/forgetPass.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Forget Password");
        stage.show();
        //hide current page
        ((Node) (event.getSource())).getScene().getWindow().hide();
    
        
    }
    
    @FXML
    private void removeError(MouseEvent event){
        this.message.setText("");
    }

}
