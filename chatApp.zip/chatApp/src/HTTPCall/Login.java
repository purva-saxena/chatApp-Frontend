/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HTTPCall;

import com.google.gson.annotations.SerializedName;

/**
 *
 * @author hinas
 */
public class Login {
    
    @SerializedName("email")
    public String email;
    
    @SerializedName("pass")
    public String password;
    
    @SerializedName("message")
    public String message;
    
    @SerializedName("response")
    public String response;

    public Login(String email, String pass) {
        this.email = email;
        this.password = pass;
    }
    
    
    public String getEmail() {
        return email;
    }
}
