/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HTTPCall;

import com.google.gson.annotations.SerializedName;

/**
 *
 * @author hinas
 */
public class Register {
    
    @SerializedName("name")
    public String name;
    
    @SerializedName("email")
    public String email;
    
    @SerializedName("pass")
    public String pass;
    
    @SerializedName("response")
    public String response;
    
    @SerializedName("message")
    public String message;

    public Register(String name, String email, String pass) {
        this.name = name;
        this.email = email;
        this.pass = pass;
    }
    
    
}
