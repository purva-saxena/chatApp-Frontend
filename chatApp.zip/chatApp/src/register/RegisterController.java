/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package register;

import HTTPCall.HTTPCallAPI;
import HTTPCall.Register;
import HTTPCall.RetrofitService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import Util.Utilities;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author hinas
 */
public class RegisterController implements Initializable {

    @FXML
    private TextField name;
    
    @FXML
    private TextField email;
    
    @FXML
    private TextField password;
    
    @FXML
    private TextField confirmPass;
    
    @FXML
    private TextField error;
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
    private Utilities Utilities = new Utilities();
    
    @FXML
    private void goToLoginPage(Event event) throws IOException{
        Parent root;
        root = FXMLLoader.load(getClass().getResource("../login/login.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Login");
        stage.show();
           
        //hide current window
        
        ((Node)(event.getSource())).getScene().getWindow().hide();
    }
    
    @FXML
    private void onRegisterButtonClick(Event event){
        
        String name = this.name.getText();
        String email = this.email.getText();
        String pass = this.password.getText();
        String confirmPass = this.confirmPass.getText();
        error.setText("");
        
        String validate = validateInput(name, email, pass, confirmPass);
        if(validate.equals("Validation successful")){
            if(Utilities.validateEmail(email) && Utilities.ValidatePass(pass)){
                System.out.println(validate);
                
                //sending requeste to server for further process i.e; creating user account
                // by saving data into database 
                
                //creating object of retrofitService class
                RetrofitService retrofitService = new RetrofitService();
                HTTPCallAPI service = retrofitService.getService();
                
                // sending url to server
                Register register = new Register(name, email, pass);
                final Call<Register> call = service.register(register);
                
                // making Asynchronous call 
                call.enqueue(new Callback<Register>() {
                    @Override
                    public void onResponse(Call<Register> call, Response<Register> response) {
                        if (response.isSuccessful()) {
                            Register apiResponse = response.body();
                            System.out.println(" ++++" + apiResponse.message + "&&&&&"+ apiResponse.response);
                            
                            error.setText("done *********** ");
                            //API response
                            if (apiResponse.response.equals("Error")) {
                                error.setText(apiResponse.message);
                            } else {
                                error.setText("You are registered successfully " + apiResponse.message);

                            }
                        } else {
                            error.setText("Request Error :: " + response.errorBody());
                        }
                    }

                    @Override
                    public void onFailure(Call<Register> call, Throwable t) {
                        error.setText("Network Error :: " + t.getLocalizedMessage());
                        System.out.println("Network Error :: " + t.getLocalizedMessage());
                    }
                });

                
            }else{
               error.setText("INVALID EMAIL OR PASSWORD ");
               error.setVisible(true);
            }
        }else{
            error.setText(validate);
            error.setVisible(true);
        }
        error.setVisible(true );
        
    }
    
    private String validateInput(String name, String email, String pass, String confirmPass){
        
        if(name==null || name.isEmpty() || email==null || email.isEmpty()|| pass==null || pass.isEmpty() || confirmPass==null || confirmPass.isEmpty()){
            return "All fields are required !! ";
        }
        
        if(!(pass.equals(confirmPass))){
            return "Passwords don't match";
        }
        
        return "Validation successful";
    }
    
    @FXML
    private void removeError(MouseEvent event){
        this.error.setText("");
    }
    
}
