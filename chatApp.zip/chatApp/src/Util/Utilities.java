/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import java.util.regex.Pattern;

/**
 *
 * @author hinas
 */
public class Utilities {

    public boolean ValidatePass(String pass) {
        if (pass.length() < 8 || pass.length() > 16) {
            return false;
        }

        String upperCaseChars = "(.*[A-Z].*)";
        if (!(pass.matches(upperCaseChars))) {
            return false;
        }

        String lowerCaseChars = "(.*[a-z].*)";
        if (!pass.matches(lowerCaseChars)) {
            return false;
        }

        String numbers = "(.*[0-9].*)";
        if (!pass.matches(numbers)) {
            return false;
        }

        String specialChars = "(.*[,~,!,@,#,$,%,^,&,*,(,),-,_,=,+,[,{,],},|,;,:,<,>,/,?].*$)";
        if (!pass.matches(specialChars)) {
            return false;
        }

        return true;
    }

    public boolean validateEmail(String email) {

        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);

        return pat.matcher(email).matches();
    }

}
