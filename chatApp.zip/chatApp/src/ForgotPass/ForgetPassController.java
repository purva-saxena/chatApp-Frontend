/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ForgotPass;

import HTTPCall.ForgetPassword;
import HTTPCall.HTTPCallAPI;
import HTTPCall.RetrofitService;
import Util.Utilities;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * FXML Controller class
 *
 * @author hinas
 */
public class ForgetPassController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField email;

    @FXML
    private TextField message;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    Utilities Utilities = new Utilities();

    @FXML
    public void backToLogin(Event event) throws IOException {

        Parent root;
        root = FXMLLoader.load(getClass().getResource("../login/login.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("login");
        stage.show();

        //hide current page
        ((Node) (event.getSource())).getScene().getWindow().hide();

    }

    @FXML
    public void resetPass(Event event) {

        String email = this.email.getText();

        if (Utilities.validateEmail(email)) {

            RetrofitService retrofitService = new RetrofitService();
            HTTPCallAPI service = retrofitService.getService();

            ForgetPassword forgetPassword = new ForgetPassword(email);

            final Call<ForgetPassword> Call = service.forgetPass(forgetPassword);

            Call.enqueue(new Callback<ForgetPassword>(){
                @Override
                    public void onResponse(Call<ForgetPassword> call, Response<ForgetPassword> response) {
                        if (response.isSuccessful()) {
                            ForgetPassword apiResponse = response.body();
                            //API response
                            if (apiResponse.response.equals("Error")) {
                                message.setText(apiResponse.message);
                            } else {
//                        here we will do some specific work.

                            }
                        } else {
                            message.setText("Request Error :: " + response.errorBody());
                        }
                    }

                    @Override
                    public void onFailure(Call<ForgetPassword> call, Throwable t) {
                        message.setText("Network Error :: " + t.getLocalizedMessage());
                        System.out.println("Network Error :: " + t.getLocalizedMessage());
                    }
                
            });
            
        }else{
            this.message.setText("Invalid Email.");
        }

    }

    @FXML
    private void removeError(MouseEvent event) {
        this.message.setText("");
    }
}
